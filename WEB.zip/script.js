// script.js
document.addEventListener('DOMContentLoaded', function () {
    // Load default content (home.html) on page load
    loadContent('home.html');
});

// Object to store user information
const userInfo = {
    name: '',
    location: ''
};

// Function to handle the Add to Cart button click
function addToCart(productId) {
    // Prompt the user to enter their name and location
    userInfo.name = prompt('Enter your name:');
    userInfo.location = prompt('Enter your location:');

    // Display a thank you message
    alert(`Thank you, ${userInfo.name}, for purchasing our product! Your order will be shipped to ${userInfo.location}.`);
}